#
# Copyright 2010-2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
#

# greengrassHelloWorld.py
# Demonstrates a simple publish to a topic using Greengrass core sdk
# This lambda function will retrieve underlying platform information and send
# a hello world message along with the platform information to the topic
# 'hello/world'. The function will sleep for five seconds, then repeat.
# Since the function is long-lived it will run forever when deployed to a
# Greengrass core.  The handler will NOT be invoked in our example since
# the we are executing an infinite loop.

import greengrasssdk
import platform
from threading import Timer
import logging
import json

# Creating a greengrass core sdk client
client = greengrasssdk.client('iot-data')

# Retrieving platform information to send from Greengrass Core
my_platform = platform.platform()

# initialize the logger
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# When deployed to a Greengrass core, this code will be executed immediately
# as a long-lived lambda function.  The code will enter the infinite while
# loop below.
# If you execute a 'test' on the Lambda Console, this test will fail by
# hitting the execution timeout of three seconds.  This is expected as
# this function never returns a result.

def turn_off_led():
    global led

    logger.info('Publish led state!!')
    data = {'led': 'off'}
    client.publish(
        topic='freertos/demos/led',
        payload=json.dumps(data))
    led = 'off'


# This is a long lived lambda so we can keep state as below
temperature = 0
humidity = 0
led = 'off'

# This is a dummy handler and will not be invoked
# Instead the code above will be executed in an infinite loop for our example
def function_handler(event, context):
    global temperature
    global humidity
    global led

    # logger.info(event)
    if 'Detect' in event:
        if event['Detect'] == "Vibrating":
            data = {'Action': 'WARNING', 'Temperature': temperature, 'Humidity': humidity}
            client.publish(
                    topic='iotdemo/topic/pub',
                    payload=json.dumps(data))

            if led == "off":
                led = 'on'
                # Asynchronously schedule this function to be run again in 5 seconds
                Timer(5, turn_off_led).start()
    else:
        temperature = event['Temperature']
        humidity = event['Humidity']

    return
